import os
import google.generativeai as genai

#api_key = "AIzaSyBr2qrGHuq52lSI3kHx6zCEUKijQcWT29g"

# Set your Google Generative AI API key
api_key = "AIzaSyDbsQKENPq6xBdzMJ5ucVVMTxT4-ItEN58"
genai.configure(api_key=api_key)

# Configuration for content generation
generation_config = {
    "temperature": 0.2,
    "top_p": 0.8,
    "top_k": 64,
    "max_output_tokens": 8192,
}

# Initialize the Generative Model with the specified configuration
model = genai.GenerativeModel(
    model_name="gemini-1.5-flash",
    generation_config=generation_config,
)

# Prepare the prompt for audio analysis
prompt_parts1 = [
    genai.upload_file("audio.mp3"),
    """Now this the audio file explaining a code base video i need to analyze the complete audio and make segments out the audio and produce a output like at each time interval what is happening in the audio
    note : 1) strictly analyze the complete and produce an line by line output and output format should be the following: timestamps | content
    2) Final timestamp should end with the time when the audio is completely played ignoring abrupt cuts
    3) In the content part please provide the whole audio text in time format MM:HH - MM:HH for complete audio length
    """
]

# Generate content based on the audio analysis prompt
response_audio = model.generate_content(prompt_parts1)

# Print response or handle exceptions
try:
    print(response_audio.text)
except Exception as e:
    print("Exception:\n", e, "\n")
    print("Response:\n", response_audio.candidates)

# Prepare the prompt for video analysis
prompt_parts1v = [
    genai.upload_file("video.mp4"),
    """Now this the video file explaining a code base video i need to analyze the complete video and make segments out the video and produce a output like at each time interval what is happening in the video
    note : 1) strictly analyze the complete video and produce an line by line output and output format should be the following: timestamps | content
    2) Final timestamp should end with the time when the video is completely played ignoring abrupt cuts
    3) In the content part please provide the whole video text in time format MM:HH - MM:HH for complete audio length"""
]

# Generate content based on the video analysis prompt
response_video = model.generate_content(prompt_parts1v)

# Print response or handle exceptions
try:
    print(response_video.text)
except Exception as e:
    print("Exception:\n", e, "\n")
    print("Response:\n", response_video.candidates)

import anthropic

# Set your Anthropic API key
api_key = "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"
client = anthropic.Anthropic(api_key=api_key)

# Create input for audio duration extraction
audio_duration_input = f"""Extract the total duration of the audio from the provided timestamp ranges and return it in the format 'minutes'. Only provide the final duration based on the last timestamp in the format M:SS, without additional text.

Timestamp with content description : '{response_audio}' """

# Generate audio duration using the Anthropic model
audio_duration = client.messages.create(
    model="claude-3-sonnet-20240229",
    max_tokens=1024,
    temperature=0.3,
    messages=[{"role": "user", "content": [{"type": "text", "text": audio_duration_input}]}]
)

# Print the audio duration
print(audio_duration.content[0].text)

# Create input for video duration extraction
video_duration_input = f"""Extract the total duration of the video from the provided timestamp ranges and return it in the format 'minutes'. Only provide the final duration based on the last timestamp in the format M:SS, without additional text.

Timestamp with content description : '{response_video}' """

# Generate video duration using the Anthropic model
video_duration = client.messages.create(
    model="claude-3-sonnet-20240229",
    max_tokens=1024,
    temperature=0.3,
    messages=[{"role": "user", "content": [{"type": "text", "text": video_duration_input}]}]
)

# Print the video duration
print(video_duration.content[0].text)

# Prepare input for synchronizing video and audio
new_input2 = f"""
**Task: Synchronize Video and Audio for Content Explanation**

**Input:**
1. Video length: {video_duration.content[0].text} minutes (mute, shows visual content)
2. Audio length: {audio_duration.content[0].text} minutes (explanation of the visual content)

**Goal:**
Create a synchronized video of {audio_duration.content[0].text} minutes by adjusting the speed of the original {video_duration.content[0].text}-minute video to match the audio explanation. The first 5 seconds of the video will play silently before the audio starts.

**Given Data:**
1. Audio Content: '{response_audio}'
2. Video Content: '{response_video}'

**Required Output:**
A table with the following columns:
1. Video Interval
2. Corresponding Audio Interval
3. Modified Video Speed

**Instructions:**
1. **First 5 seconds:** The first 5 seconds of the video will play silently with no audio.
2. **Speed adjustments:** After the first 5 seconds, align each remaining video segment with its corresponding audio segment.
3. **Proper calculation of intervals:** Ensure that **each segment** of the video maps logically to the **exact** corresponding segment of the audio. The sum of video and audio intervals should match their respective total lengths.
4. **Speed calculation:** For each video segment, the modified speed should be calculated as:
   \[
   \text{{Modified Video Speed}} = \frac{{\text{{Audio Segment Duration}}}}{{\text{{Video Segment Duration}}}}
   \]
   Express the speed factor as a decimal number rounded to two decimal places (e.g., 0.90x, 1.25x).
5. **Logical distribution of segments:** Ensure that there is no leftover time in the video. The final video timestamp must end at {audio_duration.content[0].text}.
6. **Check total duration:** After the calculated speeds are applied, the total duration of the modified video must match the audio length exactly, **{audio_duration.content[0].text} minutes**.
7. **Segment alignment:** Avoid any unnecessary gaps or segments that are not covered by the synchronization process.
8. **Complete coverage:** The entire audio must be played from start to finish without any cuts or gaps.
9. **Final duration check:** After applying the calculated speeds to video segments:
   - The total video duration must match the audio length exactly ({audio_duration.content[0].text} minutes)
   - The audio must play in its entirety at normal speed
10. **Line by line match:** Try matching line by line timestamps of both audio and video
**Example of the required output format:**

| Video Interval | Corresponding Audio Interval | Modified Video Speed |
|----------------|------------------------------|----------------------|
| 0:00 - 0:05    | 0:00 - 0:00                  | 1.00x                |
| 0:05 - 0:20    | 0:00 - 0:20                  | 0.75x                |
| 0:20 - 0:30    | 0:20 - 0:40                  | 0.75x                |
| ...            | ...                          | ...                  |
| ...  - {video_duration.content[0].text}    |  ... - {audio_duration.content[0].text}                  | [speed]x             |

---

Note : 1) ***Strictly provide the timestamps such that when speed is applied on timestamp of video it should match the total length of audio i.e. {audio_duration.content[0].text} and also for each and every timestamp of audio .
2) The audio must play continuously at normal speed (1.0x) from start to finish.
3) Remove the row of the table if it has '0.00x' in speed or if the row has any missing value.
4) Each audio segment must play smoothly and completely without any cuts or overlaps please provide timestamp video speed such that.
5) For each video interval, strictly display as table with columns "Video Interval | Corresponding Audio Interval | Modified Video Speed" ending with final timestamp matching total durations.
6) For synchronizing video with longer audio, calculate speed ratio as (video_interval_duration / audio_interval_duration) to get speeds like 0.5x that stretch video to match audio length - values greater than 1x will compress video making it shorter than audio.

"""

# Generate synchronization instructions using the Anthropic model
new_response2 = client.messages.create(
    model="claude-3-sonnet-20240229",
    max_tokens=1024,
    temperature=0.3,
    messages=[{"role": "user", "content": [{"type": "text", "text": new_input2}]}]
)

# Print synchronization instructions
print(new_response2.content[0].text)

# Prepare input for final timestamp extraction in specified format
new_input1 = f"""Give exact values of '{new_response2.content[0].text}' strictly in this below EXAMPLE format
EXAMPLE:
0:00 - 0:04|0:00 - 0:11|0.60x
0:04 - 0:20|0:11 - 0:32|2.50x
0:20 - 0:28|0:32 - 0:44|1x
0:28 - {video_duration.content[0].text}|0:44 - {audio_duration.content[0].text}|0.55x


note : strictly give in above example format and end the values at {video_duration.content[0].text} in video column and {audio_duration.content[0].text} in the audio column of the table
"""

timestamps = client.messages.create(
    model="claude-3-sonnet-20240229",
    max_tokens=1024,
    temperature=0.3,
    messages=[
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": new_input1
                }
            ]
        }
    ]
)

print(timestamps.content[0].text)

video_file = 'video.mp4'
audio_file = 'audio.mp3'

timestamps = timestamps.content[0].text

from merge import merge_video_audio_with_speed

try:
    output_file = merge_video_audio_with_speed(video_file, audio_file, timestamps)
    print(f"Merged video with speed adjustments saved as: {output_file}")
except Exception as e:
    print(f"An error occurred: {str(e)}")