# Automatic Video Editing AI Project

## Description
This project utilizes AI to analyze audio and video files, segmenting them based on content and generating synchronized output.

It merges audio and video files by analyzing their timestamps, adjusting the speed of the video to match the audio explanation, and generating a synchronized output. The code utilizes the Google Generative AI and Anthropic APIs to process the audio and video content effectively.

## Code Structure
The project contains the following main components: 

    1. video_editing_ai.ipynb or video_editing_ai.py: The main script that handles: 
       - Uploading audio and video files. 
       - Generating timestamps and content descriptions using the AI models. 
       - Calculating the total durations of the audio and video. 
       - Synchronizing the video to match the audio. 
       - Merging the audio and video files with adjusted speeds. 

    2. merge.py: A utility module that contains the function merge_video_audio_with_speed, which combines the audio and video based on the
                 calculated timestamps.

## Models used
- Gemini-1.5-Flash: For generating timestamps of audio and video along with their respective content.
- Claude-3-Sonnet-20240229: Employed to implement the speed adjustment logic, providing the synchronization table and the adjustment speeds applied to the video.

## APIs Used
Google Generative AI: Used for generating content from the audio and video files.
Anthropic API: Used for extracting the total durations of the audio and video segments.

## Known Issues
When executing video_editing_ai.py, you may encounter the following error:

"google.api_core.exceptions.FailedPrecondition: 400 The File c1a51fo5nv0r(some random file) is not in an ACTIVE state and usage is not allowed."

This issue arises because the file may not be in an active state when accessed through the Python script. 
However, running the same code in video_editing_ai.ipynb works without issue, suggesting that the Jupyter Notebook environment may handle file states differently or may include additional checks that ensure the file is active before usage.

Check the error images attached.
