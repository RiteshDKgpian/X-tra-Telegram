from moviepy.editor import VideoFileClip, AudioFileClip, concatenate_videoclips, CompositeAudioClip

def time_to_seconds(time_str):
    parts = time_str.split(':')
    if len(parts) == 2:  # MM:SS
        minutes = int(parts[0])
        seconds = float(parts[1])
        return minutes * 60 + seconds
    elif len(parts) == 3:  # HH:MM:SS
        hours = int(parts[0])
        minutes = int(parts[1])
        seconds = float(parts[2])
        return hours * 3600 + minutes * 60 + seconds
    else:
        raise ValueError("Invalid time format")



def merge_video_audio_with_speed(video_file, audio_file, timestamps):
    video = VideoFileClip(video_file)
    audio = AudioFileClip(audio_file)

    segments = []
    for line in timestamps.strip().split('\n'):
        if line.strip():
            video_time, audio_time, speed = line.split('|')
            video_start, video_end = map(time_to_seconds, video_time.split('-'))
            audio_start, audio_end = map(time_to_seconds, audio_time.split('-'))
            speed = float(speed.strip()[:-1])  # Remove 'x' and convert to float
            segments.append((video_start, video_end, audio_start, audio_end, speed))

    final_clips = []
    for i, (video_start, video_end, audio_start, audio_end, speed) in enumerate(segments):
        video_clip = video.subclip(video_start, video_end)
        audio_clip = audio.subclip(audio_start, min(audio_end, audio.duration))

        if speed != 1:
            video_clip = video_clip.speedx(speed)

        # Calculate the actual duration of the speed-adjusted video clip
        adjusted_duration = video_clip.duration

        # Adjust audio clip to match the adjusted video duration
        audio_clip = audio_clip.subclip(0, min(audio_clip.duration, adjusted_duration))

        # Set the audio of the video clip
        video_clip = video_clip.set_audio(audio_clip)
        final_clips.append(video_clip)

    final_video = concatenate_videoclips(final_clips)
    output_path = "/content/merged_speed_adjusted_video.mp4"
    final_video.write_videofile(output_path, codec="libx264", audio_codec="aac")

    video.close()
    audio.close()
    final_video.close()

    return output_path




